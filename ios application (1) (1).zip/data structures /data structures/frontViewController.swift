//
//  frontViewController.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class frontViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

   

}

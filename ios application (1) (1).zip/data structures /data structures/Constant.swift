//
//  Constant.swift
//  WeatherApp
//
//  Created by MAC-Air on 08/09/23.
//


import Foundation
import UIKit



struct ServiceAPI {
    static let baseUrl = "http://172.17.57.149/"
    static let signupUrl = baseUrl+"/javaboi1/signup.php?"
    static let loginURL = baseUrl+"/javaboi1/login.php?"
    static let BeginnerlevelURL = baseUrl+"/javaboi1/beginnerlevel.php"
    static let IntermediatelevelURL = baseUrl+"/javaboi1/intermediatelevel.php"
    static let ExpertlevelURL = baseUrl+"/javaboi1/expertlevel.php"
    static let scoreboardURL = baseUrl+"javaboi1/scoreboard1.php?"
    static let overallscoreboardURL = baseUrl+"javaboi1/overallscoreboard.php?"
    static let profileURL = baseUrl+"/javaboi1/profile.php?"
    static let achievementURL = baseUrl+"javaboi1/achievements.php"
    static let submitScoreURL = baseUrl+"javaboi1/submitscore.php?"
    static let submitScore2URL = baseUrl+"javaboi1/submitscore2.php?"
    static let submitScore3URL = baseUrl+"javaboi1/submitscore3.php?"
    static let submitScoreIntURL = baseUrl+"javaboi1/submitscoreint.php?"
    static let submitScoreInt2URL = baseUrl+"javaboi1/submitscoreint2.php?"
    static let submitScoreInt3URL = baseUrl+"javaboi1/submitscoreint3.php?"
    static let submitScoreExpURL = baseUrl+"javaboi1/submitscoreexp.php?"
    static let submitScoreExp2URL = baseUrl+"javaboi1/submitscoreexp2.php?"
    static let submitScoreExp3URL = baseUrl+"javaboi1/submitscoreexp3.php?"
    static let quizl1URL = baseUrl+"javaboi1/quizl1.php"
    static let quizl2URL = baseUrl+"javaboi1/quizl2.php"
    static let quizl3URL = baseUrl+"javaboi1/quizl3.php"
    static let level1pointsURL = baseUrl+"javaboi1/level1points.php"
    static let level2pointsURL = baseUrl+"javaboi1/level2points.php"
    static let level3pointsURL = baseUrl+"javaboi1/level3points.php"
    static let quizl1intURL = baseUrl+"javaboi1/quizl1int.php"
    static let quizl2intURL = baseUrl+"javaboi1/quizl2int.php"
    static let quizl3intURL = baseUrl+"javaboi1/quizl3int.php"
    static let Intlevel1pointsURL = baseUrl+"javaboi1/intlevel1points.php"
    static let Intlevel2pointsURL = baseUrl+"javaboi1/intlevel2points.php"
    static let Intlevel3pointsURL = baseUrl+"javaboi1/intlevel3points.php"
    static let quizl1expURL = baseUrl+"javaboi1/quizl1exp.php"
    static let quizl2expURL = baseUrl+"javaboi1/quizl2exp.php"
    static let quizl3expURL = baseUrl+"javaboi1/quizl3exp.php"
    static let Explevel1pointsURL = baseUrl+"javaboi1/explevel1points.php"
    static let Explevel2pointsURL = baseUrl+"javaboi1/explevel2points.php"
    static let Explevel3pointsURL = baseUrl+"javaboi1/explevel3points.php"
}



//
//  OverallscoreModel.swift
//  javaBoi
//
//  Created by SAIL on 17/10/23.
//

import Foundation

// MARK: - Welcome
struct overallscore: Codable {
    var leaderboard: [Leaderboard]?
}

// MARK: - Leaderboard
struct Leaderboard: Codable {
    var username, overallPoints: String?

    enum CodingKeys: String, CodingKey {
        case username
        case overallPoints = "overall_points"
    }
}

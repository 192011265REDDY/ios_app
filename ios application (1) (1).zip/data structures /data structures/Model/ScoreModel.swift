//
//  ScoreModel.swift
//  javaBoi
//
//  Created by SAIL on 27/10/23.
//


import Foundation

// MARK: - Welcome
struct ScoreModel: Codable {
    var status: Bool?
    var message: String?
    var data: [Score]?
}

// MARK: - Datum
struct Score: Codable {
    var username, points: String?
    

}

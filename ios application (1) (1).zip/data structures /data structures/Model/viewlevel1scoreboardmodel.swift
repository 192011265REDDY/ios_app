//
//  viewlevel1scoreboardmodel.swift
//  javaBoi
//
//  Created by SAIL L1 on 11/10/23.
//

// MARK: - Welcome
struct level1scoreboard: Codable {
    var status, message: String?
    var data: [Datum]?
}

// MARK: - Datum
struct Datum: Codable {
    var username, points: String?
}

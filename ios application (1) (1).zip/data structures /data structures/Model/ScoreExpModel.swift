//
//  ScoreExpModel.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct ScoreExpModel: Codable {
    var status: Bool?
    var message: String?
    var data: [ScoreExpModelData]?
}

// MARK: - Datum
struct ScoreExpModelData: Codable {
    var username, expLevel1: String?

    enum CodingKeys: String, CodingKey {
        case username
        case expLevel1 = "exp_level1"
    }
}

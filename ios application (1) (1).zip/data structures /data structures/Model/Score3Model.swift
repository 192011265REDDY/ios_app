//
//  Score3Model.swift
//  javaBoi
//
//  Created by SAIL on 30/10/23.
//

import Foundation
struct Score3Model: Codable {
    var status: Bool?
    var message: String?
    var data: [Score3ModelData]?
}

// MARK: - Datum
struct Score3ModelData: Codable {
    var username, level3: String?
    

}

//
//  AnswerViewController.swift
//  data structures
//
//  Created by SAIL on 28/10/23.
//

//  CorrectViewController.swift
//  JsonResponse
//
//  Created by Haris Madhavan on 23/10/23.
//

import UIKit

protocol NextButtonDelegate: AnyObject {
    func nextButtonTapped()
}

class AnswerViewController: UIViewController {
    
    var ResponseData: JsonResponseModel!
    weak var delegate: NextButtonDelegate?
    @IBOutlet weak var answerView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var answerLabel: UILabel!
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if let answerStatus = UserDefaults.standard.string(forKey: "AnswerStatus") {
                if answerStatus == "Correct" {
                    titleLabel.text = "Correct Answer"
                } else if answerStatus == "Wrong" {
                    titleLabel.text = "Wrong Answer"
                    answerView.backgroundColor = .red.withAlphaComponent(0.5)
                    nextButton.backgroundColor = .red
                }
            }
            
            // Clear the stored answer status
            UserDefaults.standard.removeObject(forKey: "AnswerStatus")
    }
    
    @IBAction func buttonAction(_ sender: Any) {
        delegate?.nextButtonTapped()
        self.dismiss(animated: true)
    }
    
    
}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


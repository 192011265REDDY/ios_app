//
//  loginViewController.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class loginViewController: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var username: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var forgetpassword: UIButton!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var account: UILabel!
    @IBOutlet weak var singup: UIButton!
   
    var apiURL = String()
    var loginModel: Login!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        

    }
    @IBAction func login(_ sender: Any) {
        
       
        apiURL = "http://172.17.57.149/javaboi1/login.php?username=\(username.text  ?? "")&password=\(password.text ?? "")"
        
        if username.text == "" && password.text == "" {
            let alert = UIAlertController(title: "Alert", message: "Textfield is Empty", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            present(alert, animated: true)
        } else {
            getLoginAPI()
        }
    }
    @IBAction func signUpButton(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Signupviewcontroller") as! Signupviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    func getLoginAPI() {
        APIHandler().getAPIValues(type: Login.self, apiUrl: apiURL, method: "GET") { result in
            switch result {
            case .success(let data):
                self.loginModel = data
                print(self.loginModel.data ?? "")
                DispatchQueue.main.async {
                    if self.username.text != self.loginModel.data?.first?.username && self.password.text != self.loginModel.data?.first?.password {
                        let alert = UIAlertController(title: "Alert", message: "Incorrect ID or Password", preferredStyle: UIAlertController.Style.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                        self.present(alert, animated: true)
                    } else {
                        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
                        let vc = storyboard.instantiateViewController(withIdentifier: "competencyviewcontroller") as! competencyviewcontroller
                        self.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

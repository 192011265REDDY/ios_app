//
//  learnviewcontroller.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class learnviewcontroller: UIViewController {

    @IBOutlet weak var home: UIImageView!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var quiz: UIButton!
    
    @IBOutlet weak var learnTableView: UITableView!
    var video: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        self.learnTableView.delegate = self
        self.learnTableView.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    @IBAction func QUIZ(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Quiz1viewcontroller") as! Quiz1viewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension learnviewcontroller: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "learnTableViewCell", for: indexPath) as! learnTableViewCell
        
        // YouTube Video ID
           let videoID = "-n96oYVQz4Y?si=41x_2U-lercPpZsV"
           
        if let url = URL(string: "https://youtu.be/ZV1GwGA1QlY?si=lMkHYnAljV2ys9mL") {
                let requestObj = URLRequest(url: url)
                cell.webView.load(requestObj)
            }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 800
    }
}

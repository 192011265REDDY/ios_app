//
//  Scoreboardcell.swift
//  data structures
//
//  Created by SAIL on 25/10/23.
//

import UIKit

class Scoreboardcell: UITableViewCell {

    @IBOutlet weak var pointsimage: UIImageView!
    @IBOutlet weak var score: UILabel!
    @IBOutlet weak var certificate: UIImageView!
    @IBOutlet weak var level: UILabel!
    @IBOutlet weak var level1: UILabel!
    @IBOutlet weak var points: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}

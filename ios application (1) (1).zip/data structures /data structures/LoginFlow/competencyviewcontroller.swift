//
//  competencyviewcontroller.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class competencyviewcontroller: UIViewController {

    @IBOutlet weak var competency: UILabel!
    @IBOutlet weak var beginner: UIButton!
    @IBOutlet weak var intermediate: UIButton!
    @IBOutlet weak var expert: UIButton!
    @IBOutlet weak var profilebtn: UIImageView!
    @IBOutlet weak var scoreboardbtn: UIImageView!
    @IBOutlet weak var logoutbtn: UIImageView!
    @IBOutlet weak var medal: UIImageView!
    @IBOutlet weak var profile: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        scoreboardbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Scoreboardviewcontroller") as! Scoreboardviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        profilebtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profileviewcontroller") as! profileviewcontroller
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        
        logoutbtn.addAction(for: .tap){
            let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "loginViewController") as! loginViewController
            self.navigationController?.pushViewController(signupVC, animated: true)
        }
        // Do any additional setup after loading the view.
    }
    

    
    @IBAction func beginner(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Beginner")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    
    @IBAction func intermediate(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Intermediate")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    @IBAction func expert(_ sender: Any) {
        UserDefaultsManager.shared.saveUserCompetency("Expert")
        let signupVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
        self.navigationController?.pushViewController(signupVC, animated: true)
    }
    /*
     @IBAction func expert(_ sender: Any) {
     let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "levelViewController") as! levelViewController
     self.navigationController?.pushViewController(loginVC, animated: true)
     }
     // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

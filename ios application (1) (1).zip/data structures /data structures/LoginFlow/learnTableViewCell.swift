//
//  learnTableViewCell.swift
//  data structures
//
//  Created by SAIL L1 on 01/11/23.
//

import UIKit
import WebKit

class learnTableViewCell: UITableViewCell {


    @IBOutlet weak var webView: WKWebView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

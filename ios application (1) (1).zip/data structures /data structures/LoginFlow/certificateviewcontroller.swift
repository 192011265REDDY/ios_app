//
//  certificateviewcontroller.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class certificateviewcontroller: UIViewController {

    @IBOutlet weak var logo: UIImageView!
    @IBOutlet weak var Next: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

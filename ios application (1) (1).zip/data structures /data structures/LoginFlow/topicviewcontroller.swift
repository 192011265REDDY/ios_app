//
//  topicviewcontroller.swift
//  data structures
//
//  Created by SAIL on 04/10/23.
//

import UIKit

class topicviewcontroller: UIViewController {

    @IBOutlet weak var datastructures: UIImageView!
    @IBOutlet weak var graphs: UILabel!
    @IBOutlet weak var queue: UILabel!
    @IBOutlet weak var list: UIImageView!
    @IBOutlet weak var trees: UILabel!
    @IBOutlet weak var arrays: UILabel!
    @IBOutlet weak var stack: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBAction func stack(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    @IBAction func NEXT(_ sender: Any) {
        let loginVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "learnviewcontroller") as! learnviewcontroller
        self.navigationController?.pushViewController(loginVC, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  compilerViewController.swift
//  data structures
//
//  Created by SAIL L1 on 21/12/23.
//

import UIKit
import WebKit

class CompilerViewController: UIViewController {

    @IBOutlet weak var compilerwebview: WKWebView!
 
  
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        if let url = URL (string:"http://172.17.57.149/javaboi1/compiler1.html"){
            let requestObj = URLRequest(url: url)
            self.compilerwebview.load(requestObj)
            self.compilerwebview.scrollView.maximumZoomScale = 1.0
            self.compilerwebview.scrollView.minimumZoomScale = 1.0
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
